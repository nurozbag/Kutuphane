﻿using Book_Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book_Buisness.Abstract
{
    public interface iMyBookService
    {
        List<MyBook> GetAll();
        MyBook GetById(int myBookId);
        void Add(MyBook myBook);
        void Update(MyBook myBook);
        void Delete(MyBook myBook);

    }
}
