﻿using Book_DAL.Abstract;
using Book_Entities.Concrete;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Book_DAL.Concrete.EntityFramework
{
    public class EfPublisherDal : iPublisherDal
        
    {
        AppDbContext _context = new AppDbContext();
        public void Add(Publisher publisher)
        {
           _context.Publishers.Add(publisher);
            _context.SaveChanges();
        }

        public void Delete(Publisher publisher)
        {
            _context.Publishers.Remove(publisher);
            _context.SaveChanges();
        }

        public List<Publisher> GetAll()
        {
            return _context.Publishers.Where(x=>x.IsDelete!=true).ToList();
        }

        public Publisher GetById(int id)
        {
            return _context.Publishers.Find(id);
        }

        public void Update(Publisher publisher)
        {
            var result = _context.Publishers.Find(publisher.Id);
            if(result != null)
            {
                result.Name = publisher.Name;
                _context.SaveChanges();
            }
          
        }
    }
}
