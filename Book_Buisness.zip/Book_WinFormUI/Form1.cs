using Book_Buisness.Concrete;
using Book_Entities.Concrete;

namespace Book_WinFormUI
{
    public partial class Form1 : Form
    {
        AuthorManager authorManager=new AuthorManager();
        CategoryManager categoryManager=new CategoryManager();
        PublisherManager publisherManager=new PublisherManager();
        MyBookManager myBookManager=new MyBookManager();
        public Form1()
        {
            InitializeComponent();
            comboBox1.DataSource = authorManager.GetAll();
            comboBox2.DataSource = categoryManager.GetAll();
            comboBox3.DataSource = publisherManager.GetAll();

            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "Id";
            comboBox2.DisplayMember = "Name";
            comboBox2.ValueMember = "Id";
            comboBox3.DisplayMember= "Name";
            comboBox3.ValueMember = "Id";

            dataGridView1.DataSource=myBookManager.GetAll();
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[3].Visible = false;
            dataGridView1.Columns[4].Visible = false;
            dataGridView1.Columns[5].Visible = false;
            dataGridView1.Columns[6].Visible = false;
            dataGridView1.Columns[7].Visible = false;
            dataGridView1.Columns[8].Visible = false;
            dataGridView1.Columns[9].Visible = false;




        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(textBox1.Text!=""&& textBox2.Text != "")
            {
                MyBook myBook = new MyBook();
                myBook.Name = textBox1.Text;
                myBook.ISBN = textBox2.Text;
                myBook.AuthorId = Int32.Parse(comboBox1.SelectedValue.ToString());
                myBook.CategoryId = Int32.Parse(comboBox2.SelectedValue.ToString());
                myBook.PublisherId=Int32.Parse(comboBox3.SelectedValue.ToString());
                myBook.IsDelete = false;

                myBookManager.Add(myBook);
                dataGridView1.DataSource=myBookManager.GetAll();
                textBox1.Text = "";
                textBox2.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void comboBox2_MouseClick(object sender, MouseEventArgs e)
        {
            comboBox2.DataSource = categoryManager.GetAll();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form_Authors form_Author = new Form_Authors ();
            form_Author.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form_Publisher form_Publisher=new Form_Publisher ();
            form_Publisher.ShowDialog();
        }

        private void comboBox1_MouseClick(object sender, MouseEventArgs e)
        {
            comboBox1.DataSource = authorManager.GetAll();

        }

        private void comboBox3_MouseClick(object sender, MouseEventArgs e)
        {
            comboBox3.DataSource = publisherManager.GetAll();

        }
    }
}