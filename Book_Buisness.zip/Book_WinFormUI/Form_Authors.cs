﻿using Book_Buisness.Concrete;
using Book_Entities.Concrete;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_WinFormUI
{
    public partial class Form_Authors : Form
    {
        AuthorManager authorManager = new AuthorManager();
        int _id=0;
        public Form_Authors()
        {
            InitializeComponent();
            dataGridView1.DataSource = authorManager.GetAll();
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[2].Visible = false;
            dataGridView1.Columns[3].Visible = false;
            button2.Enabled = false;
            button3.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                Author author = new Author();
                author.Name = textBox1.Text;
                authorManager.Add(author);
                dataGridView1.DataSource = authorManager.GetAll();
                textBox1.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Author editAuthor = authorManager.GetById(_id);
            editAuthor.Name = textBox1.Text;
            authorManager.Update(editAuthor);
            button2.Enabled=false;
            button3.Enabled = false;
            textBox1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Author silAuthor = authorManager.GetById(_id);
            if (silAuthor != null)
            {
                authorManager.Delete(silAuthor);
                dataGridView1.DataSource = authorManager.GetAll();
                button2.Enabled = false;
                button3.Enabled = false;
                textBox1.Text = "";
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                _id = Int32.Parse(row.Cells[0].Value.ToString());
                Author editAuthor = authorManager.GetById(_id);
                textBox1.Text = editAuthor.Name;
                button2.Enabled = true;
                button3.Enabled = true;
            }
        }
    }
}
